

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <?php
     $title = "Table User";
     include_once("title.php");
     include('head.php');
     include('navbar.php');
    ?>
</head>
<body>
 
<br>
<br>
<br>
<br>
 <form action="table_user.php" method="post" enctype="multipart/form-data" > 
      <div class="form-group col-md-4">
        <label for="Year">Year</label>
        <select type="text" class="form-control" id="Year" name="Year">
          <?php 
            for ($i=1380; $i < 1500; $i++) { 
              echo "<option value='$i'>$i</option>";
            }
           ?>
        </select>   
      </div>
      <div class="form-group col-md-4">
        <label for="Season">Season</label>
        <select type="text" class="form-control" id="Season" name="Season">
          <option></option>
          <option value="Spring">Spring</option>
          <option value="summer">summer</option>
          <option value="Fall">Fall</option>
          <option value="winter">winter</option>
          
        </select>   
      </div>
      <div class="form-group col-md-4">
        <label for="gender">Gender</label>
        <select type="text" class="form-control" id="gender" name="gender">
          <option></option>
          <option value="male">Male</option>
          <option value="fmale">Fmale</option>
        </select>   
      </div>
      <button type="submit" name="submit" class="btn btn-primary">Search</button>
      <button type="submit" class="btn btn-primary">cancle</button>
</form>
<table class="table table-bordered " >
    <thead>
      <tr>
        <th>Firstname</th>
        <th>Lastname</th>
        <th>Email</th>
        <th>Email</th>
        <th>Photo</th>
        <th>action</th>
      </tr>
    </thead>
    <tbody>
      <?php 
          include 'lib/crud.php';
          $db = new CRUD();
 

          $list_of_user="";
          //create array for list of field
           $fields = array('Year','Season','gender');

           //create varible for condition
           $condition = array();
           if (isset($_POST['submit'])) {
             foreach ($fields as $field) {
               if (isset($_POST['field']) && $_POST['field'] !='') {
                $condition[] = "$field ='".$_POST[$field]."'";
               }
             }
             $sql = "SELECT * from user";
             if (count($condition) > 0) {
             //impload() 
              $sql .= "where" .implode("and", $condition);
              $rows = $db->select_raw($sql);
             }
           }



          //TEST SELECT FUNCTIOn

          foreach ($rows as $re) {
            $id= $re["id"];
            $first_name= $re["first_name"];
            $last_name= $re["last_name"];
            $email= $re["email"];
            $Photo= $re["photo"];
            $gender= $re["gender"];
            $list_of_user .= "
               <tr>
                  <td>$id</td>
                  <td>$first_name</td>
                  <td>$last_name</td>
                  <td>$email</td>
                  <td><img src='userPictures/$photo'></td>
                  <td>$gender</td>
                  <td>
                     <a href='table_user.php?deleteID=$id & url=$photo' class='btn btn-primary'>Delete</a>
                     <a href='table_user.php?updateID=$id class='btn btn-primary'>Update</a> 
                  </td>
                </tr>";
            $num++;
          }


        ?>
     
    </tbody>
  </table>
  <?php
  //dleted user
  if (isset($_GET('deleteID'))) {
    $id = (int) $_GET('deleteID');
    $url = $_GET('url');
    $de = $db->delete('user','id=$id and photo="$url"');
    if ($de) {
      unlink("userPictures/");
      header("location:table_user.php?deleted=1");
    }

  }

  ?>
 
</body>
</html>