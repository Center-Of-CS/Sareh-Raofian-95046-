
<!doctype html>
<html class="no-js" lang="en">

 <?php
session_start();

if(isset($_POST["submit"])){
$uname = $_POST["username"];
$pwd = $_POST["password"];

if($uname =="admin" && $pwd=="admin"){
  $countfile = "countfile.txt";
  $files = fopen($countfile, "r+") or die("can not opening $countfile");
   flock($files, LOCK_EX)  or die("can not lock file");
  $counter = fgets($countfile,4096) or die("can not get file");
  $counter = rtrime($counter."/n");
  if (is_numeric($counter)) {
    $count = $counter+1;
    rewind($files);
    $re = fputs($files,$count);
    print($count);

    # code...
  }
  else{
    print  "error: $counter=$counter<= not numberic value ";
  }
  fclose($files);


   
	if(isset($_POST["remember"])){
	
	setcookie("username",$uname,time()+3600);
	setcookie("password",$pwd,time()+3600);
	
	}else{
	
	setcookie("username",$uname,time()-3600);
	setcookie("password",$pwd,time()-3600);
	}

	$_SESSION["login_authority"]="success";
	header("location:login.php");
	}

}

if(isset($_GET["logout"])){
$_SESSION = array();
session_unset();
session_destroy();
$_SESSION = [];
} 
?> 

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
    <?php
        $title = "singnup";
        include_once("title.php");
        include('head.php');
        
        include('navbar.php');;
      ?>
  <style>
      form{
        width:500px;
        margin:auto;
      }
      label{
        color: white;
      }
      .form-control{
        background-color: white;
      }
      .btn{
        width: 100px;
        margin: auto;
      }
  </style>
</head>
<body>
   <br><br><br><br><br>
	<div class="error-pagewrap">
		<div class="error-page-int">
			<div class="text-center m-b-md custom-login">
				<h3>PLEASE LOGIN TO APP</h3>
			</div>
			<div class="content-error">
				<div class="hpanel">
          <div class="panel-body">
              <form action="index.php" method="post" id="loginForm">
                  <div class="form-group">
                      <label class="control-label" for="username">Username</label>
                      <input type="text" placeholder="example@gmail.com" title="Please enter you username" required="" value="" name="username" id="username" class="form-control">
                  </div>
                  <div class="form-group">
                      <label class="control-label" for="password">Password</label>
                      <input type="password" title="Please enter your password" placeholder="******" required="" value="" name="password" id="password" class="form-control">
                  </div>
                  <div class="checkbox login-checkbox">
                      <label>
					                 <input type="checkbox" <?php if(isset($_COOKIE["username"])){ echo "checked='checked'"; }?> class="i-checks" name="remember"> Remember me </label>
                      <p class="help-block small"></p>
                  </div>
                  <button class="btn btn-success btn-block loginbtn" type="submit" name="submit">Login</button>
              </form>
          </div>
      </div>
			</div>
		</div>   
    </div>
</body>

</html>