<div class="row"  id="homenav">
  <div class="col">
     <nav class="navbar navbar-dark navbar-expand-sm fixed-top nav1">

      <a class="navbar-brandn lrg-logo" >
        <img src="img/logoimgwhite.png" width="70px">
     </a>

      <button type="button" class="navbar-toggler" data-toggle="collapse" data-target="#mynav"> 
        <span class="navbar-toggler-icon"></span>
      </button>
      <div class="navbar-collapse collapse" id="mynav">
        <ul class="nav navbar-nav ml-auto" >
          <li class="nav-item">
            <a href="#homenav" class="nav-link"><i class ="fa fa-home" style="padding-right: 1%"></i>Home</a>
          </li>
           <li class="nav-item">
            <a class="nav-link" href="#about"><i class="fa fa-address-book" style="padding-right: 1%"></i>About</a>
          </li>
           <li class="nav-item">
            <a href="#contact" class="nav-link"><i class="fas fa-phone" style="padding-right: 1%" ></i>Contact</a>
          </li>
          <li class="nav-item">
            <a href="signup.php" class="nav-link"><i class="fas fa-phone" style="padding-right: 1%" ></i>Signup</a>
          </li>
          <li class="nav-item">
            <a href="login.php" class="nav-link"><i class="fas fa-phone" style="padding-right: 1%" ></i>Login</a>
          </li>
          
          <li class="nav-item">
            <a href="login.php?logout=1" class="nav-link"><i class="fas fa-phone" style="padding-right: 1%" ></i>Log Out</a>
          </li>
        </ul>
      </div>
    </nav>
   </div>
</div>