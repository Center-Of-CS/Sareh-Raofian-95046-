
<!DOCTYPE html>
<html>
<?php
      $title = "story";
      include_once("title.php");
    
    ?>

<meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="fonts/font-awesome/css/font-awesome.css" rel="stylesheet">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" href="css/grey.css">
    <link rel='stylesheet' href='css/fontw3.css'>
    <link rel="stylesheet" href="css/font-awesome2.css">
    <script src="js/bootstrap.min.js"></script>
<style>
html,body,h1,h2,h3,h4,h5 {font-family: "Open Sans", sans-serif}
body{
	font-family:Adobe Caslon Pro;
}
</style>
<body class="w3-theme-l5">

<!-- Navbar -->
<div class="w3-top" >
	<div class="w3-bar w3-theme-d2 w3-left-align w3-large">
  <a class="w3-bar-item w3-button w3-hide-medium w3-hide-large w3-right w3-padding-large w3-hover-white w3-large w3-theme-d2" href="javascript:void(0);" onclick="openNav()"><i class="fa fa-bars"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large w3-theme-d4"><i class="fa fa-home w3-margin-right"></i>Home</a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="News"><i class="fa fa-globe"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Account Settings"><i class="fa fa-user"></i></a>
  <a href="#" class="w3-bar-item w3-button w3-hide-small w3-padding-large w3-hover-white" title="Messages"><i class="fa fa-envelope"></i></a>
  
    
  <a href="index.html" class="w3-bar-item w3-button w3-hide-small w3-right w3-padding-large w3-hover-whit" title="My Account"><img src="img\logoimgwhite.png" width="50px" class="w3-circle" style="height:40px;width:50px" alt="Avatar"></a>
 </div>
</div>

<!-- Navbar on small screens -->
<div id="navDemo" class="w3-bar-block w3-theme-d2 w3-hide w3-hide-large w3-hide-medium w3-large">
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 1</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 2</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">Link 3</a>
  <a href="#" class="w3-bar-item w3-button w3-padding-large">My Profile</a>
</div>

<!-- Page Container -->
<div class="w3-container w3-content" style="max-width:1700px;margin-top:70px; " >    
  <!-- The Grid -->
  <div class="w3-row">
    <!-- Left Column -->
    <div class="w3-col m3">
      <!-- Profile -->
      <div class="w3-card-2 w3-round w3-white">
        <div class="w3-container" style="background-image:transparent;">
         <h4 class="w3-center">My Profile</h4>
         <p class="w3-center"><img src="img/44 (334).jpg" class="w3-circle" style="height:106px;width:106px" alt="Avatar"></p>
         <hr>
         <p><i class="fa fa-pencil fa-fw w3-margin-right w3-text-theme"></i> setting</p>
         <p><i class="fa fa-home fa-fw w3-margin-right w3-text-theme"></i>Home Page</p>
         <p><i class="fa fa-birthday-cake fa-fw w3-margin-right w3-text-theme"></i> March 19, 2017</p>
        </div>
      </div>
      <br>
     
      <br>
      
      <!-- Interests --> 
      <div class="w3-card-2 w3-round w3-white w3-hide-small">
        <div class="w3-container">
          <p>Interests</p>
          <p>
            <span class="w3-tag w3-small w3-theme-d5 ">News</span>
            <span class="w3-tag w3-small w3-theme-d4"></span>
            <span class="w3-tag w3-small w3-theme-d3">Labels</span>
            <span class="w3-tag w3-small w3-theme-d2">Games</span>
            <span class="w3-tag w3-small w3-theme-l1">Friends</span>
          </p>
        </div>
      </div>
      <br>
      
      <!-- Alert Box -->
      <div class="w3-container w3-display-container w3-round w3-theme-l4 w3-border w3-theme-border w3-margin-bottom w3-hide-small">
        <span onclick="this.parentElement.style.display='none'" class="w3-button w3-theme-l3 w3-display-topright">
          <i class="fa fa-remove"></i>
        </span>
        <p style="color:white;"><strong>Hey!</strong></p>
        <p style="color:white;">People are looking at your profile.</p>
      </div>
    
    <!-- End Left Column -->
    </div>
    
    <!-- Middle Column -->
    <div class="w3-col m7">
    
      <div class="w3-row-padding">
        <div class="w3-col m12">
          <div class="w3-card-2 w3-round w3-white">
            <div class="w3-container w3-padding">
              <h6 class="w3-opacity">write you post:</h6>
              <p contenteditable="true" class="w3-border w3-padding">Status:</p>
              <button type="button" class="w3-button w3-theme"><i class="fa fa-pencil"></i>  Post</button> 
            </div>
          </div>
        </div>
      </div>
      
      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
        <img src="img/images (1).jpg" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
        <span class="w3-right w3-opacity">4 min</span>
        <h4>Sahar Gul </h4><br>
        <hr class="w3-clear">
			<p>
				On Tuesday, December 27, 2011, Baghlan Police Corps found half the body of Sahar Gul, a 15 year old girl from the basement of her husband's house. Sahar Gul, who was given to her husband seven months ago in Badakhshan province, had been imprisoned for five months in a dark room under her husband's house. Baghlan police said he was severely beaten and beaten by his husband and his family. Police officials in Baghlan province told reporters that she had been angry with her husband and family after Sahar Gul rejected her husband's demand for self-defense. Sahargol was immediately taken to the hospital in Pul-e-Khumri, northern Afghanistan, where he was admitted. According to the doctors of Pul-e-Khumri Hospital, the left and left fingers of Sahargol are drawn by her husband, her arm has been broken and psychologically badly damaged.
        Sahar Gul is now being transferred to Kabul for treatment and is being housed in a specially managed hospital. Soraya, the head of the Afghan Ministry of Public Health, told reporters that healing may be months away, but the psychological effects of torture and violence may persist forever in her life. But this is not the only flower of the flower that in such a state is caught in Afghanistan because of its womanhood. The story of Sarghal is just one of the tragic tragedies of women in Afghanistan, which has now become so sunny. Many of the women's stories in Afghanistan are always worn for various reasons, and their perpetrators are unpunished

			</p>

        <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom color"><i class="fa fa-thumbs-up"></i>  Like</button> 
        <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom color"><i class="fa fa-comment"></i>  Comment</button> 
      </div>
      
      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
        <img src="img/images (1).jpg" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
        <span class="w3-right w3-opacity">16 min</span>
        <h4>Maryam</h4><br>
        <hr class="w3-clear">
			<p>
        ین داستان به قلم خود این دختر افغانستانی نوشته شده ، شاید از خواندنش زندگی رقت بار در افغانستان را بیشتر احساس کنید.

      اسم من مریم است بنت عبدالرحمن باشنده ای ولایت غور ولسوالی ساغر. ۲۰ سال عمر دارم.

      می خواهم قصه واقعی از سرنوشت زندگی خودم را به عنوان یک دختر افغانستانی به گوش تمام جهانیان برسانم که در آینده هیچ دختر افغانستانی از حق و حقوق خود بی بهره نماند. من ۱۳ ساله صنف ۵ مکتب به فکر درس و تعلیم خود بودم که در آینده یک داکتر ورزیده در ولایت خود که نیاز مبرم مردم ما می باشد باشم.

      البته در این زمان از طرف فامیل پدرم برایم خواستگاری آمده بودند که خودم در جریان نبودم. بدون رضایت خودم خانواده ام تصمیم گرفتند که من را نامزد کنند که خودم اصلا رضایت نداشتم. هر چند که التماس کردم که من به درس و تعلیم ام ادامه دهم تا این که به سن قانونی برسم که در آن زمان تصمیم ازدواج خواهد گرفتم ولی هیچ به گوش فامیل نرفت.

      ناچار پیش کاکایم رفتم که شاید پدرم به حرف های او گوش دهد که متاسفانه کاکایم به حرف هایم خنده زده گفت: این تصمیم از فامیل است نه از تو، تو حق نداری تصمیم بگیری و چند حرف دیگر هم زد که اشک هایم جاری شد. از اینجا نا امید شدم رفتم خانه مامایم و به زاری افتادم که هیچ مفید واقع نشد و کسی به ناله هایم اعتنا نکرد.

      بدبختانه پدر و مادر ظالم ام با آن همه ناله ها و زاری هایم که به ضرر فامیل هم نبود تا به سن قانونی برسم من را نامزد کردند و من بدون درگاه الهی دیگر راه چاره ای نداشتم و همیشه دوچشمانم پر از اشک بود. من با یک شخص به نام غوث الدین که ۳۵ سال داشت انجام گرفت. من آرزو داشتم که همسر آینده ام با سواد باشد که متاسفانه عوث الدین بی سواد بود. به مدت ۲ سال نامزد بودیم چون قرار این بود که تا صنف ۱۲ را تمام نکنم عروسی نمی کنیم که این شرط را خانواده شوهرم نیز قبول کرده بودند البته ظاهری نه باطنی.

      در یکی از شب ها ی دوران نامزدی برایم تابلیت خواب داده بودند که این یک امر غیر قانونی بوده و تجاوز به شمار می رود. اما آنها اینکار را کردند. بعد از گذشت چند ماه من بدبخت حامله شدم که از این حمل خانواده ام را مقصر می دانستم چون همرایم با خشونت برخورد می کردند. بعد از سپری شدن ۷ ماه از حمل دو فامیل تصمیم گرفتند که عروسی کنیم که نه تنها خوشبین نبودم بلکه بکلی رضایت نداشتم چون بغض سنگینی بخاطر کار ناجایزی که در حقم صورت گرفته بود در دلم گره خورده بود.

      ناگفته نماند که چندین بار دست به خودکشی زدم که از این عروسی خلاص شوم اما موفق نشدم. بلاخره عروسی ما شد و من به خانه بخت (خانه جدید) رفتم. از این که قلبم باری سنگینی را حمل می کرد و نمی توانستم زیاد تحمل کنم بعد از چند روز گذشت عروسیمان شوهرم من را لت و کوب کرد که در اثر آن ولادت قبل از وقت کردم. بعد از ولادت خشونت آمیز بسیار حالم بد شده بود و همچنان بعد از چند ساعت ولادت طفلی از جنس پسر او را از دست دادم (طفل مرد).

      البته خانه ما نزدیک شفاخانه ولایتی در مرکز ولایت بود ولی این خانواده سنگ دل که هیچ رحمی بدل نداشند من را به شفاخانه انتقال ندادند. مشکلات به حدی را که در این ولادت تجربه کردم بار دلم را سنگین تر ساخت. بر علاوه این همه شوهرم من را نمی گذاشت که به خانه پدرم بروم و مدت ها شده بود که پدر مادرم را ندیده بودم. موبایل هم نداشتم و حتی مانع صحبت کردن با آنها می شد. با این همه ظلم باز هم تحمل می کردم و با آنها خوبی می کردم تا شاید دل شوهرم را بعد از ولادت به دست آوردم تا اجازه دهد که درسم را ادامه دهم ولی هیچ جواب مثبت از آنها نمی شنیدم.

      همه آنها یک فکر و مفکوره داشتند و رفتن زن به مکتب و درس خواندن را غیر ضروری می دانستند. شوهرم از صبح تا شام پشت دهقانی میرفت و دروازه خانه برویم قفل می زد که مبادا کسی از فامیلم را ببینم. مدت یک سال همی قسم زندگی را سپری کردم و سروصدا ها و لت وکوب های شوهرم همیشه و همچنان ادامه داشت. فقط دلیل این همه این بود که من می خواستم مکتب بروم و درس بخوانم. من قول داده بودم که از زندگی با او خوشم اما اجازه دهد که ادامه تحصیل کنم ولی او قبول نمی کرد

    </p>
        <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom color"><i class="fa fa-thumbs-up"></i>  Like</button> 
        <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom color"><i class="fa fa-comment"></i>  Comment</button> 
      </div>  

      <div class="w3-container w3-card-2 w3-white w3-round w3-margin"><br>
        <img src="img/images (1).jpg" alt="Avatar" class="w3-left w3-circle w3-margin-right" style="width:60px">
        <span class="w3-right w3-opacity">32 min</span>
        <h4>Fahtma </h4><br>
        <hr class="w3-clear">
       
			<p>
				On Tuesday, December 27, 2011, Baghlan Police Corps found half the body of Sahar Gul, a 15 year old girl from the basement of her husband's house. Sahar Gul, who was given to her husband seven months ago in Badakhshan province, had been imprisoned for five months in a dark room under her husband's house. Baghlan police said he was severely beaten and beaten by his husband and his family. Police officials in Baghlan province told reporters that she had been angry with her husband and family after Sahar Gul rejected her husband's demand for self-defense. Sahargol was immediately taken to the hospital in Pul-e-Khumri, northern Afghanistan, where he was admitted. According to the doctors of Pul-e-Khumri Hospital, the left and left fingers of Sahargol are drawn by her husband, her arm has been broken and psychologically badly damaged.
        Sahar Gul is now being transferred to Kabul for treatment and is being housed in a specially managed hospital. Soraya, the head of the Afghan Ministry of Public Health, told reporters that healing may be months away, but the psychological effects of torture and violence may persist forever in her life. But this is not the only flower of the flower that in such a state is caught in Afghanistan because of its womanhood. The story of Sarghal is just one of the tragic tragedies of women in Afghanistan, which has now become so sunny. Many of the women's stories in Afghanistan are always worn for various reasons, and their perpetrators are unpunished

			</p>
        <button type="button" class="w3-button w3-theme-d1 w3-margin-bottom color"><i class="fa fa-thumbs-up"></i>  Like</button> 
        <button type="button" class="w3-button w3-theme-d2 w3-margin-bottom color"><i class="fa fa-comment"></i>  Comment</button> 
      </div> 
      
    <!-- End Middle Column -->
    </div>
    
    <!-- Right Column -->
    <div class="w3-col m2">
      
      <br>
      
      <div class="w3-card-2 w3-round w3-white w3-center">
        <div class="w3-container">
          <p>Friend Request</p>
          <img src="img/Forough.jpg" alt="Avatar" style="width:50%"><br>
          <span>Sarah Tomlinson</span>
          <div class="w3-row w3-opacity">
            <div class="w3-half">
              <button class="w3-button w3-block w3-green w3-section" title="Accept"><i class="fa fa-check"></i></button>
            </div>
            <div class="w3-half">
              <button class="w3-button w3-block w3-red w3-section" title="Decline"><i class="fa fa-remove"></i></button>
            </div>
          </div>
        </div>
      </div>
      <br>
      <div class="w3-card-2 w3-round w3-white w3-padding-16 w3-center">
        <p>Afganistan</p>
      </div>
      <br>  
    <!-- End Right Column -->
    </div>
    
  <!-- End Grid -->
  </div>
  
<!-- End Page Container -->
</div>
<br>


 
<script>
// Accordion
function myFunction(id) {
    var x = document.getElementById(id);
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
        x.previousElementSibling.className += " w3-theme-d1";
    } else { 
        x.className = x.className.replace("w3-show", "");
        x.previousElementSibling.className = 
        x.previousElementSibling.className.replace(" w3-theme-d1", "");
    }
}

// Used to toggle the menu on smaller screens when clicking on the menu button
function openNav() {
    var x = document.getElementById("navDemo");
    if (x.className.indexOf("w3-show") == -1) {
        x.className += " w3-show";
    } else { 
        x.className = x.className.replace(" w3-show", "");
    }
}
</script>

</body>
</html> 
